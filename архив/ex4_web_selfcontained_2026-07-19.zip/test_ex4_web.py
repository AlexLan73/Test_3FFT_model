"""Приёмка ex4-web — живая панель канона §1.6 (🚫 pytest, правило 04).

Полный размер 64×64×4096 (решение Alex 1A), но 2 такта — историю гоняем один раз на класс.

Запуск:  .venv/Scripts/python.exe demo/tests/test_ex4_web.py
"""
from __future__ import annotations

import json
import re
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np  # noqa: E402

from common.runner import AssertionGroup, TestRunner  # noqa: E402
from demo.ex4_flight.example import Ex4Flight, Ex4Params  # noqa: E402
from demo.ex4_flight.web import CROP_HALF, build_page, history_to_json  # noqa: E402


class Ex4WebTests(TestRunner):
    """Один прогон истории на класс (кеш) + сериализация + страница."""

    _cached: Ex4Flight | None = None

    def setup(self) -> None:
        if Ex4WebTests._cached is None:
            ex = Ex4Flight(params=Ex4Params(tacts=2))
            ex.run_history(np.random.default_rng(ex.seed))
            Ex4WebTests._cached = ex
        self.ex = Ex4WebTests._cached
        self.data = history_to_json(self.ex)

    def test_history_serialized(self) -> AssertionGroup:
        g = AssertionGroup("ex4web.serialize")
        d = self.data
        g.add(d["nTicks"] == 2, f"nTicks={d['nTicks']}, ожидалось 2")
        g.add(len(d["ticks"]) == 2, "все такты сериализованы")
        t = d["ticks"][-1]
        g.add(len(t["pts"]) > 0, "точки такта присутствуют")
        g.add(t["band"] is not None, "полоса barrage в данных")
        g.add(len(t["trk"]) > 0, "треки в данных")
        g.add(all(len(tr["h"]) <= d["kTrail"] for tr in t["trk"]),
              f"история трека обрезана до K={d['kTrail']}")
        g.add(json.dumps(d) is not None, "структура JSON-сериализуема")
        return g

    def test_slices_cropped(self) -> AssertionGroup:
        """Решение Alex 2A: срезы — кроп ±8 бинов, не полный nx×ny."""
        g = AssertionGroup("ex4web.crop")
        w = 2 * CROP_HALF + 1
        slices = [s for t in self.data["ticks"] for s in t["sl"]]
        g.add(len(slices) > 0, "срезы присутствуют (треки возраста >=2 на такте 2)")
        for s in slices:
            g.add(len(s["m"]) == w and all(len(row) == w for row in s["m"]),
                  f"кроп №{s['id']} должен быть {w}×{w}")
            ix, iy = s["kx"] + self.ex._p.nx // 2, s["ky"] + self.ex._p.ny // 2
            g.add(s["x0"] <= ix <= s["x0"] + w and s["y0"] <= iy <= s["y0"] + w,
                  f"бин трека №{s['id']} внутри кропа")
        return g

    def test_final_features(self) -> AssertionGroup:
        """Признаки §4.11 — финального такта (канон ex4: таблица финальная)."""
        g = AssertionGroup("ex4web.final_feats")
        ff = self.data["finalFeats"]
        g.add(len(ff) > 0, "финальные признаки хотя бы одного трека")
        need = {"pr", "hoyer", "main_frac", "lobe_ratio", "max_mean", "energy"}
        for tid, rec in ff.items():
            g.add(need.issubset(rec["f"].keys()),
                  f"трек {tid}: все 6 признаков §4.11, есть {sorted(rec['f'])}")
        return g

    def test_page_selfcontained(self) -> AssertionGroup:
        g = AssertionGroup("ex4web.page")
        with tempfile.TemporaryDirectory() as tmp:
            path = build_page(self.data, Path(tmp) / "index.html")
            html = path.read_text(encoding="utf-8")
        g.add("__DATA__" not in html, "плейсхолдер данных заменён")
        g.add("https://" not in html and "http://" not in html,
              "ноль внешних URL (офлайн-требование)")
        for cid in ("c3d", "fld", "slices", "tbl"):
            g.add(f'id="{cid}"' in html, f"элемент канона {cid} на странице")
        m = re.search(r"const DATA = (\{.*?\});\n", html, re.S)
        g.add(m is not None and json.loads(m.group(1))["nTicks"] == 2,
              "встроенный JSON валиден")
        return g


if __name__ == "__main__":
    sys.exit(0 if Ex4WebTests().run_all() else 1)
