"""ex4-web — живая web-панель полёта по канону §1.6 (спека web_panel_flight_2026-07-19).

Web = ТРЕТИЙ рендерер истории `Ex4Flight` (после GIF×2 и last_frame, правило R5 —
второй раз не считать): `run_history()` → сериализация `TactRecord` в JSON (срезы —
кроп ±8 бинов вокруг трека, решение Alex 2A) → самодостаточный HTML+JS (vanilla canvas,
ноль внешних URL — plotly дома нет, работает офлайн и на Debian).

Элементы канона:
  ① 3D-сцена (kx × позиция × ky): детекции такта (цвет=дБ, turbo), истина-треугольники,
     barrage-линия, хвосты истины; ВРАЩЕНИЕ мышью + зум колесом (чего нет у GIF).
  ② Поле nx×ny: треки со следом K=8 (альфа/размер растут к голове — формула
     `_compose_frame`), № + ✈ у устойчивых, квадрат носителя, рамка barrage.
  ③ Ряд тепловых срезов по трекам + ТАБЛИЦА признаков §4.11 (решение Alex: «кусочек
     с таблицей используем») с тултипами-описаниями; вердикт «ЛЕТИТ» — из трека
     (`is_moving`, §4-бис.4). Признаки — финального такта (как в ex4).

Запуск:  .venv/Scripts/python.exe demo/ex4_flight/web.py            # полный канон (1A), ~2.5 мин
         .venv/Scripts/python.exe demo/ex4_flight/web.py --tacts 6  # быстрый прогон
Выход:   demo/graphics/ex4_flight/web/index.html  → открыть в браузере
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

# Конвенция репо: работает форма `python demo/ex4_flight/web.py`.
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np  # noqa: E402

from core.graphics import Projection  # noqa: E402  — ЕДИНАЯ модель камеры (математика в core)
from demo.ex4_flight.example import Ex4Flight, Ex4Params, TactRecord  # noqa: E402

CROP_HALF = 8    # решение Alex 2A: окно среза ±8 бинов вокруг трека

# Стационарные помехи-станции (не двигаются — «работают» с фиксированного угла), каждая
# со своим значком (типы из industrial_interference_classification.md). Размещены в
# свободных углах поля, вне полосы barrage и трасс цели/носителя.
STATIONS = (
    {"type": "radar", "label": "другой радар (CW)", "kx": -22.0, "ky": -21.0},
    {"type": "ham", "label": "радиолюбитель", "kx": 21.0, "ky": -24.0},
)


def _crop_slice(sl: dict[str, Any], nx: int, ny: int, half: int) -> dict[str, Any]:
    """Кроп energy_db вокруг углового бина трека: {x0, y0, m[(2h+1)×(2h+1)]}."""
    e = sl["energy_db"]
    w = 2 * half + 1
    ix = int(round(sl["kx"])) + nx // 2
    iy = int(round(sl["ky"])) + ny // 2
    x0 = int(np.clip(ix - half, 0, max(0, nx - w)))
    y0 = int(np.clip(iy - half, 0, max(0, ny - w)))
    m = e[x0:x0 + w, y0:y0 + w]
    return {"x0": x0, "y0": y0, "m": [[round(float(v), 1) for v in row] for row in m]}


def _tick_json(rec: TactRecord, p: Ex4Params, k_trail: int) -> dict[str, Any]:
    tgt, comb = rec.truth["target"], rec.truth["comb"]
    bkx, bky, _ = rec.truth["barrage"]
    return {
        "truth": {"t": [round(tgt[0], 2), round(tgt[1], 2), int(tgt[2])],
                  "c": [round(comb[0], 2), round(comb[1], 2), int(comb[2])],
                  "b": [round(bkx, 2), round(bky, 2)]},
        "band": [round(v, 1) for v in rec.band_angle] if rec.banded else None,
        "pts": [[round(q.kx, 1), round(q.ky, 1), int(q.pos), round(q.db, 1)]
                for q in rec.points],
        "trk": [{"id": t["id"], "kx": round(t["kx"], 2), "ky": round(t["ky"], 2),
                 "mv": int(t["is_moving"]),
                 "h": [[round(h[1], 2), round(h[2], 2)] for h in t["history"][-k_trail:]]}
                for t in rec.tracks],
        "sl": [{"id": s["track_id"], "kx": round(float(s["kx"]), 1),
                "ky": round(float(s["ky"]), 1), "pos": int(s["pos"]),
                "mv": int(s["is_moving"]),
                **_crop_slice(s, p.nx, p.ny, CROP_HALF)}
               for s in rec.slices],
    }


def history_to_json(ex: Ex4Flight) -> dict[str, Any]:
    """История Ex4Flight → данные страницы (кроп срезов, финальные признаки)."""
    p = ex._p
    final_feats: dict[str, Any] = {}
    if ex._history:
        for s in ex._history[-1].slices:
            if s["features"]:
                final_feats[str(s["track_id"])] = {
                    "label": s["label"],
                    "f": {k: round(float(v), 4) for k, v in s["features"].items()},
                }
    return {
        "nx": p.nx, "ny": p.ny, "nAxis": p.n_axis, "kTrail": p.k_trail,
        "nTicks": len(ex._history),
        "stats": {k: str(v) for k, v in ex._stats.items()},
        "finalFeats": final_feats,
        "stations": [dict(s) for s in STATIONS],     # стационарные помехи (не двигаются)
        "cam": Projection(nx=p.nx, ny=p.ny, n_range=p.n_axis).as_js(),  # единая камера из core
        "ticks": [_tick_json(r, p, p.k_trail) for r in ex._history],
    }


# ── страница: самодостаточная, тёмная (палитра ex4: #0d1117/#58a6ff/#f0883e/#f85149) ──
_PAGE = """<!DOCTYPE html>
<html lang="ru"><head><meta charset="utf-8">
<title>ex4 · полёт — живая панель (канон §1.6)</title>
<style>
  :root { --bg:#0d1117; --panel:#161b22; --line:#30363d; --fg:#c9d1d9; --dim:#8b949e;
          --trk:#58a6ff; --comb:#f0883e; --bar:#f85149; --lime:#7ee787; }
  body { background:var(--bg); color:var(--fg); font:13px/1.45 "Segoe UI",sans-serif; margin:0; }
  header { padding:8px 16px; border-bottom:1px solid var(--line); display:flex; gap:12px;
           align-items:center; flex-wrap:wrap; }
  h1 { font-size:15px; margin:0 8px 0 0; font-weight:600; }
  button, select { background:var(--panel); color:var(--fg); border:1px solid var(--line);
           border-radius:6px; padding:4px 10px; cursor:pointer; font-size:13px; }
  button.on { border-color:var(--comb); color:var(--comb); }
  input[type=range] { width:240px; vertical-align:middle; }
  .wrap { display:flex; gap:12px; padding:12px 16px; flex-wrap:wrap; }
  .card { background:var(--panel); border:1px solid var(--line); border-radius:8px;
          padding:8px 10px; }
  .card h2 { font-size:12px; margin:0 0 6px; color:var(--dim); font-weight:600; }
  canvas { display:block; }
  .slrow { display:flex; gap:10px; }
  .sl { text-align:center; cursor:pointer; }
  .sl .cap { font-size:10.5px; color:var(--dim); margin-top:3px; white-space:nowrap; }
  .sl canvas { border:2px solid transparent; border-radius:4px; }
  .sl.sel canvas { border-color:var(--comb); }
  table { border-collapse:collapse; font-size:12px; font-variant-numeric:tabular-nums; }
  td, th { padding:3px 9px; text-align:right; border-bottom:1px solid var(--line); }
  th { color:var(--dim); font-weight:600; cursor:help; }
  tr.sel td { background:#21262d; }
  tr { cursor:pointer; }
  .mv { color:var(--lime); font-weight:600; } .no { color:var(--dim); }
  #legend { display:none; font-size:12px; color:var(--dim); max-width:900px; }
  #legend.show { display:block; }
  #legend b { color:var(--fg); }
  #status { color:var(--dim); }
  #status b { color:var(--bar); font-weight:600; }
</style></head><body>
<header>
  <h1>ex4 · полёт: цель + носитель гребёнки + barrage → null → треки</h1>
  <button id="play" class="on">⏸ пауза</button>
  <select id="speed"><option value="400">0.5×</option><option value="200" selected>1×</option>
    <option value="100">2×</option></select>
  <input type="range" id="tick" min="0" value="0">
  <span id="status"></span>
  <button id="trails" class="on">след: вкл</button>
  <button id="resetView">сброс вида</button>
  <button id="legendBtn">описание признаков</button>
</header>
<div class="wrap">
  <div class="card"><h2>① 3D (kx × позиция × ky) — вращать мышью, зум колесом ·
      <span style="color:var(--trk)">▲цель</span> · <span style="color:var(--comb)">▲носитель</span> ·
      <span style="color:var(--bar)">▎barrage</span> · точки=детекции (дБ)</h2>
    <canvas id="c3d" width="560" height="540"></canvas></div>
  <div class="card"><h2>② поле kx×ky: треки, след K тактов · № + ✈=летит ·
      <span style="color:var(--comb)">△гребёнка</span> · <span style="color:var(--bar)">▢barrage</span> ·
      <span style="color:#a371f7">📡 др. радар</span> · <span style="color:#3fb950">◉ радиолюбитель</span></h2>
    <canvas id="fld" width="540" height="540"></canvas></div>
</div>
<div class="wrap">
  <div class="card"><h2>③ срезы по трекам (окно 16, кроп ±8 бинов, дБ)</h2>
    <div class="slrow" id="slices"></div></div>
  <div class="card"><h2>③ параметры треков (признаки §4.11 — финальный такт) ·
      клик по строке = выбор</h2>
    <table id="tbl"></table>
    <div id="legend"></div></div>
</div>
<script>
const DATA = __DATA__;
const NX = DATA.nx, NY = DATA.ny, NAX = DATA.nAxis, K = DATA.kTrail;
const C = { trk:"#58a6ff", comb:"#f0883e", bar:"#f85149", fg:"#c9d1d9", dim:"#8b949e",
            radar:"#a371f7", ham:"#3fb950" };

// ── значки помех (canvas-глифы) ──
function glyphTri(g, x, y, color){          // гребёнка DRFM — треугольник
  g.strokeStyle = color; g.lineWidth = 2; g.beginPath();
  g.moveTo(x, y-7); g.lineTo(x-6, y+5); g.lineTo(x+6, y+5); g.closePath(); g.stroke(); }
function glyphSquare(g, x, y, color, h=4){  // barrage — небольшой квадрат-рамка
  g.strokeStyle = color; g.lineWidth = 2; g.strokeRect(x-h, y-h, 2*h, 2*h); }
function glyphAntenna(g, x, y, color){      // другой радар/станция — мачта + радиоволны
  g.strokeStyle = color; g.lineWidth = 1.6;
  g.beginPath(); g.moveTo(x, y+8); g.lineTo(x, y-5); g.stroke();               // мачта
  g.beginPath(); g.moveTo(x-5, y+8); g.lineTo(x, y+1); g.lineTo(x+5, y+8); g.stroke(); // опоры
  for(const r of [4, 7]){ g.beginPath();
    g.arc(x, y-5, r, -Math.PI*0.6, Math.PI*0.1); g.stroke(); } }               // волны
function glyphHam(g, x, y, color){          // радиолюбитель — неподвижная излучающая точка
  g.fillStyle = color; g.beginPath(); g.arc(x, y, 2.6, 0, 7); g.fill();
  g.strokeStyle = color; g.lineWidth = 1;
  for(const r of [5, 8]){ g.beginPath(); g.arc(x, y, r, 0, 7); g.stroke(); } }  // кольца вещания
function drawStation(g, x, y, type){
  if(type === "radar") glyphAntenna(g, x, y, C.radar); else glyphHam(g, x, y, C.ham); }
let tick = 0, playing = true, trails = true, sel = null, timer = null, zoom = 1.0;

// ═══ Projection — ЕДИНАЯ модель камеры сцены (Value Object, GRASP Information Expert) ═══
// Конвенция знаков осей задана ЗДЕСЬ ОДИН РАЗ и общая для ОБОИХ видов (поле ② и 3D ①):
//   +kx → влево,  +ky → вверх,  дальность r → вглубь.  Камера стоит в нулевой дальности.
// Поле = проекция БЕЗ наклона (дальность схлопнута); 3D = та же камера + наклон skew (объём).
// Единственный источник знаков (ndcX/ndcY) ⇒ виды физически не могут разойтись ⇒ зеркальность
// 3D↔поле невозможна by construction. Вращение мышью меняет ТОЛЬКО наклон, не переворачивает.
// Параметры и формулы — из ЕДИНОЙ модели core/graphics/camera.py (Projection, покрыта
// tests/test_camera.py). JS — тонкий рендер: повторяет ровно те же ndc_x/ndc_y/scene.
const AZ0 = DATA.cam.az0, EL0 = DATA.cam.el0, FIT = DATA.cam.fit;
const Projection = {
  az: DATA.cam.az, el: DATA.cam.el,                    // орбитальные углы (ПОЛНОЕ вращение)
  ndcX(kx){ return -kx/(NX/2); },                      // +kx → −X (ВЛЕВО) — единый знак азимута
  ndcY(ky){ return -ky/(NY/2); },                      // +ky → −Y (ВВЕРХ) — единый знак угла места
  reset(){ this.az = AZ0; this.el = EL0; },
  // поле ② — плоская проекция kx-ky (дальность не смещает экран)
  field(kx, ky, W, H){
    return [W/2 + this.ndcX(kx)*(W/2-30), H/2 + this.ndcY(ky)*(H/2-32)]; },
  // 3D ① — орбитальная камера (та же формула, что core/graphics/camera.py::Projection.scene)
  scene(kx, ky, r, W, H){
    const s = 175*zoom;
    const ax = kx/(NX/2), ay = ky/(NY/2), zc = (r/NAX - 0.5)*2;
    const ca = Math.cos(this.az), sa = Math.sin(this.az),
          ce = Math.cos(this.el), se = Math.sin(this.el);
    const xr = ax*ca - zc*sa, zr = ax*sa + zc*ca;
    const yr = ay*ce - zr*se, depth = ay*se + zr*ce;
    return [W/2 - xr*FIT*s, H/2 - yr*FIT*s, depth];     // −x: kx влево; −y: ky вверх (как поле)
  },
};

// turbo-колормапа (опорные точки + лерп), диапазон дБ [-25, 0]
const TB = [[48,18,59],[70,107,227],[40,187,235],[74,236,152],[182,240,66],
            [249,189,38],[245,96,23],[190,25,7]];
function turbo(db){ const t = Math.min(1, Math.max(0, (db+25)/25));
  const x = t*(TB.length-1), i = Math.floor(x), f = x-i, a = TB[i],
        b = TB[Math.min(i+1, TB.length-1)];
  return `rgb(${a.map((v,k)=>Math.round(v+(b[k]-v)*f)).join(",")})`; }

const FEATS = [["pr","PR","пик/фон: у точечной цели мал, у шума ~сотни"],
  ["hoyer","Hoyer","разреженность спектра окна (0=размазан, 1=один пик)"],
  ["main_frac","MainFrac","доля энергии главного лепестка"],
  ["lobe_ratio","LobeRatio","боковой лепесток / главный"],
  ["max_mean","MaxMean","контраст: максимум / среднее окна"],
  ["energy","Energy","полная энергия окна"]];

const T = () => DATA.ticks[tick];

// ── ① 3D: тонкая обёртка над ЕДИНОЙ Projection.scene (аргумент pos = дальность r) ──
function p3(kx, pos, ky){
  const c = document.getElementById("c3d");
  return Projection.scene(kx, ky, pos, c.width, c.height);
}
function line3(g, a, b){ g.beginPath(); g.moveTo(a[0],a[1]); g.lineTo(b[0],b[1]); g.stroke(); }
function poly3(g, pts){ g.beginPath();                     // замкнутый контур грани
  pts.forEach((p,i)=> i ? g.lineTo(p[0],p[1]) : g.moveTo(p[0],p[1])); g.closePath(); g.stroke(); }
function tri(g, p, color){ g.fillStyle = color; g.beginPath();
  g.moveTo(p[0], p[1]-6); g.lineTo(p[0]-5, p[1]+4); g.lineTo(p[0]+5, p[1]+4);
  g.closePath(); g.fill(); }
// деления осей: kx/ky симметричны (бины), позиция 0..NAX
const ticks = (a, b, n) => Array.from({length:n+1}, (_,i)=> a+(b-a)*i/n);
const fmt = v => Math.round(v).toString();
function depth(kx, pos, ky){ return p3(kx, pos, ky)[2]; }   // глубина точки (дальше = больше)
function draw3d(){
  const c = document.getElementById("c3d"), g = c.getContext("2d");
  g.clearRect(0,0,c.width,c.height);
  const t = T(), E = NX/2, F = NY/2;
  const TKX = ticks(-E, E, 4), TKY = ticks(-F, F, 4), TP = ticks(0, NAX, 4);
  // ── сетка на 3 ЗАДНИХ гранях (по глубине центра грани) — «box» как в matplotlib ──
  const wKx = depth(-E, NAX/2, 0) >= depth(E, NAX/2, 0) ? -E : E;   // задняя боковая
  const wP  = depth(0, 0, 0)      >= depth(0, NAX, 0)    ?  0 : NAX; // задняя торцевая
  const wKy = depth(0, NAX/2, -F) >= depth(0, NAX/2, F)  ? -F : F;  // пол/потолок дальний
  g.setLineDash([3, 4]);                                            // сетка граней — пунктир
  g.strokeStyle = "#3a4457"; g.lineWidth = 1;
  for(const pv of TP) line3(g, p3(wKx, pv, -F), p3(wKx, pv, F));    // грань kx=wKx
  for(const kv of TKY) line3(g, p3(wKx, 0, kv), p3(wKx, NAX, kv));
  for(const kv of TKX) line3(g, p3(kv, wP, -F), p3(kv, wP, F));     // грань pos=wP
  for(const kv of TKY) line3(g, p3(-E, wP, kv), p3(E, wP, kv));
  for(const kv of TKX) line3(g, p3(kv, 0, wKy), p3(kv, NAX, wKy));  // грань ky=wKy
  for(const pv of TP) line3(g, p3(-E, pv, wKy), p3(E, pv, wKy));
  g.setLineDash([]);                                               // периметр — сплошной, ярче
  g.strokeStyle = "#586275"; g.lineWidth = 1.3;
  poly3(g, [p3(wKx,0,-F), p3(wKx,NAX,-F), p3(wKx,NAX,F), p3(wKx,0,F)]);
  poly3(g, [p3(-E,wP,-F), p3(E,wP,-F), p3(E,wP,F), p3(-E,wP,F)]);
  poly3(g, [p3(-E,0,wKy), p3(E,0,wKy), p3(E,NAX,wKy), p3(-E,NAX,wKy)]);
  g.strokeStyle = "#4a5163"; g.lineWidth = 1;                      // рёбра куба
  for(const s of [-1,1]) for(const q of [-1,1]){
    line3(g, p3(-E, (s+1)/2*NAX, q*F), p3(E, (s+1)/2*NAX, q*F));
    line3(g, p3(s*E, 0, q*F), p3(s*E, NAX, q*F));
    line3(g, p3(s*E, (q+1)/2*NAX, -F), p3(s*E, (q+1)/2*NAX, F)); }
  // ── деления с числами на рёбрах у задних граней ──
  // общий угол трёх осей — (wKx, wP, wKy): крайнюю метку каждой оси там пропускаем (не слипались)
  g.fillStyle = C.dim; g.font = "10px sans-serif"; g.textAlign = "center";
  for(const kv of TKX){ if(kv === wKx) continue;
    const L = p3(kv, wP, wKy); g.fillText(fmt(kv), L[0], L[1]+13); }
  for(const pv of TP){ if(pv === wP) continue;
    const L = p3(wKx, pv, wKy); g.fillText(fmt(pv), L[0], L[1]+13); }
  g.textAlign = "right";
  for(const kv of TKY){ if(kv === wKy) continue;
    const L = p3(wKx, wP, kv); g.fillText(fmt(kv), L[0]-8, L[1]+3); }
  // ── подписи осей (у середин нижних рёбер, с отступом наружу от центра куба) ──
  g.fillStyle = C.fg; g.font = "bold 11px sans-serif"; g.textAlign = "center";
  const O = p3(0, NAX/2, 0);                              // центр куба на экране
  const outward = (L, k=26) => { const dx = L[0]-O[0], dy = L[1]-O[1],
    n = Math.hypot(dx,dy)||1; return [L[0]+dx/n*k, L[1]+dy/n*k]; };
  let L = outward(p3(0, wP, wKy)); g.fillText("kx (азимут)", L[0], L[1]);
  L = outward(p3(wKx, NAX/2, wKy)); g.fillText("позиция →", L[0], L[1]);
  L = outward(p3(wKx, wP, 0)); g.fillText("ky", L[0], L[1]);
  g.textAlign = "left";
  const b = t.truth.b;                                     // barrage-линия
  g.strokeStyle = C.bar; g.lineWidth = 4; g.globalAlpha = 0.5;
  line3(g, p3(b[0], 0, b[1]), p3(b[0], NAX, b[1]));
  g.globalAlpha = 1;
  if(trails) for(const [key,color] of [["t",C.trk],["c",C.comb]]){   // хвосты истины
    g.strokeStyle = color; g.lineWidth = 1.3; g.globalAlpha = 0.55; g.beginPath();
    for(let s = Math.max(0, tick-K); s <= tick; s++){
      const q = DATA.ticks[s].truth[key], pp = p3(q[0], q[2], q[1]);
      s===Math.max(0,tick-K) ? g.moveTo(pp[0],pp[1]) : g.lineTo(pp[0],pp[1]); }
    g.stroke(); g.globalAlpha = 1; }
  t.pts.map(q => [p3(q[0], q[2], q[1]), q[3]])             // детекции по глубине
    .sort((a,b2)=>b2[0][2]-a[0][2])
    .forEach(([pp,db])=>{ g.fillStyle = turbo(db);
      g.beginPath(); g.arc(pp[0], pp[1], 3.5, 0, 7); g.fill(); });
  tri(g, p3(t.truth.t[0], t.truth.t[2], t.truth.t[1]), C.trk);
  tri(g, p3(t.truth.c[0], t.truth.c[2], t.truth.c[1]), C.comb);
  for(const st of DATA.stations){                          // стационарные помехи на pos=0 (у зрителя)
    const pp = p3(st.kx, 0, st.ky); drawStation(g, pp[0], pp[1], st.type); }
}

// ── ② поле: тонкие обёртки над ЕДИНОЙ Projection.field (те же знаки осей, что 3D) ──
function fx(kx){ const c = document.getElementById("fld");
  return Projection.field(kx, 0, c.width, c.height)[0]; }
function fy(ky){ const c = document.getElementById("fld");
  return Projection.field(0, ky, c.width, c.height)[1]; }
function drawField(){
  const c = document.getElementById("fld"), g = c.getContext("2d");
  g.clearRect(0,0,c.width,c.height);
  g.strokeStyle = "#21262d"; g.lineWidth = 1;
  for(let k = -NX/2; k <= NX/2; k += 10){
    g.beginPath(); g.moveTo(fx(k), fy(-NY/2)); g.lineTo(fx(k), fy(NY/2)); g.stroke();
    g.beginPath(); g.moveTo(fx(-NX/2), fy(k)); g.lineTo(fx(NX/2), fy(k)); g.stroke(); }
  g.strokeStyle = "#30363d"; g.strokeRect(fx(-NX/2), fy(NY/2), fx(NX/2)-fx(-NX/2),
                                          fy(-NY/2)-fy(NY/2));
  g.fillStyle = C.dim; g.font = "10px sans-serif";
  g.textAlign = "center";                                  // числа делений
  for(let k = -NX/2; k <= NX/2; k += 10) g.fillText(k, fx(k), fy(-NY/2)+14);
  g.textAlign = "right";
  for(let k = -NY/2; k <= NY/2; k += 10) g.fillText(k, fx(-NX/2)-6, fy(k)+3);
  g.textAlign = "center"; g.fillStyle = C.fg; g.font = "bold 11px sans-serif";
  g.fillText("kx (азимут)", c.width/2, c.height-5);
  g.save(); g.translate(12, c.height/2+40); g.rotate(-Math.PI/2);
  g.fillText("ky (угол места)", 0, 0); g.restore();
  g.textAlign = "left";
  const t = T();
  for(const tr of t.trk){
    const hist = trails ? tr.h : tr.h.slice(-1), n = hist.length;
    const stable = tr.h.length >= 3;
    hist.forEach((hq,j)=>{ const a = 0.15+0.85*(j+1)/n;
      g.globalAlpha = stable ? a : 0.35; g.fillStyle = C.trk;
      g.beginPath(); g.arc(fx(hq[0]), fy(hq[1]), stable ? (2+4*a) : 2, 0, 7); g.fill(); });
    g.globalAlpha = 1;
    if(stable){ g.fillStyle = (sel===tr.id) ? C.comb : C.trk;
      g.font = "bold 11px sans-serif";
      g.fillText("№"+tr.id+(tr.mv ? "✈" : ""), fx(tr.kx)+8, fy(tr.ky)-6); }
    if(sel===tr.id){ g.strokeStyle = C.comb; g.lineWidth = 1.6;
      g.beginPath(); g.arc(fx(tr.kx), fy(tr.ky), 11, 0, 7); g.stroke(); } }
  const cb = t.truth.c;                                    // носитель гребёнки — треугольник
  glyphTri(g, fx(cb[0]), fy(cb[1]), C.comb);
  const b = t.truth.b;                                     // barrage — небольшой квадрат
  glyphSquare(g, fx(b[0]), fy(b[1]), C.bar, 5);
  for(const st of DATA.stations)                           // стационарные помехи (не двигаются)
    drawStation(g, fx(st.kx), fy(st.ky), st.type);
}

// ── ③ срезы + таблица ──
function drawSlices(){
  const box = document.getElementById("slices");
  const t = T();
  box.innerHTML = "";
  if(!t.sl.length)
    box.innerHTML = "<div style='color:#8b949e;padding:24px'>треки формируются " +
                    "(срезы появляются с возраста 2 такта)…</div>";
  for(const s of t.sl){
    const d = document.createElement("div");
    d.className = "sl"+(sel===s.id ? " sel" : "");
    const cv = document.createElement("canvas");
    const n = s.m.length; cv.width = cv.height = 187;
    const g = cv.getContext("2d"), cell = cv.width/n;
    for(let i=0;i<n;i++) for(let j=0;j<s.m[i].length;j++){
      g.fillStyle = turbo(s.m[i][j]);
      g.fillRect(j*cell, cv.height-(i+1)*cell, cell+0.5, cell+0.5); }
    const mx = (s.ky+NY/2-s.y0+0.5)*cell, my = cv.height-(s.kx+NX/2-s.x0+0.5)*cell;
    g.strokeStyle = "#fff"; g.lineWidth = 1.6;
    g.beginPath(); g.arc(mx, my, 9, 0, 7); g.stroke();
    const cap = document.createElement("div");
    cap.className = "cap";
    cap.textContent = `№${s.id} окно=${s.pos} kx=${s.kx>=0?"+":""}${s.kx} ` +
                      `ky=${s.ky>=0?"+":""}${s.ky} ${s.mv ? "ЛЕТИТ" : "—"}`;
    d.appendChild(cv); d.appendChild(cap);
    d.onclick = () => { sel = (sel===s.id) ? null : s.id; drawAll(); };
    box.appendChild(d); }
}
function drawTable(){
  const t = T();
  let h = "<tr><th>№</th><th>окно</th><th>kx</th><th>ky</th>";
  for(const [,name,tip] of FEATS) h += `<th title="${tip}">${name}</th>`;
  h += `<th title="вердикт из ТРЕКА (is_moving, §4-бис.4), не из куба">вердикт</th></tr>`;
  for(const s of t.sl){
    const ff = DATA.finalFeats[String(s.id)];
    h += `<tr data-id="${s.id}" class="${sel===s.id?'sel':''}">` +
         `<td><b>${s.id}</b></td><td>${s.pos}</td><td>${s.kx}</td><td>${s.ky}</td>`;
    for(const [key] of FEATS){
      const v = ff ? ff.f[key] : undefined;
      h += `<td>${v===undefined ? "·" : Number(v).toPrecision(3)}</td>`; }
    h += `<td class="${s.mv?'mv':'no'}">${s.mv ? "✈ ЛЕТИТ" : "—"}</td></tr>`; }
  const tbl = document.getElementById("tbl");
  tbl.innerHTML = h;
  tbl.querySelectorAll("tr[data-id]").forEach(r => r.onclick = () => {
    const id = +r.dataset.id; sel = (sel===id) ? null : id; drawAll(); });
}
function drawStatus(){
  const t = T();
  document.getElementById("tick").value = tick;
  document.getElementById("status").innerHTML =
    `такт ${tick+1}/${DATA.nTicks}` +
    (t.band ? ` · <b>полоса@(${t.band[0]}, ${t.band[1]})→null</b>` : "") +
    ` · цель найдена ${DATA.stats.target_found} · ${DATA.stats.models}`;
}
function drawAll(){ draw3d(); drawField(); drawSlices(); drawTable(); drawStatus(); }

// ── легенда признаков ──
document.getElementById("legend").innerHTML =
  FEATS.map(([,n,tip]) => `<b>${n}</b> — ${tip}`).join(" · ") +
  " · <b>вердикт</b> — «летит» решает ТРЕК (движение между тактами, §4-бис.4), не куб";

// ── контролы ──
function schedule(){ clearInterval(timer);
  if(playing) timer = setInterval(()=>{ tick = (tick+1)%DATA.nTicks; drawAll(); },
                                  +document.getElementById("speed").value); }
document.getElementById("play").onclick = e => { playing = !playing;
  e.target.textContent = playing ? "⏸ пауза" : "▶ пуск";
  e.target.classList.toggle("on", playing); schedule(); };
document.getElementById("speed").onchange = schedule;
document.getElementById("tick").oninput = e => { tick = +e.target.value; drawAll(); };
document.getElementById("trails").onclick = e => { trails = !trails;
  e.target.textContent = "след: " + (trails ? "вкл" : "выкл");
  e.target.classList.toggle("on", trails); drawAll(); };
document.getElementById("legendBtn").onclick = () =>
  document.getElementById("legend").classList.toggle("show");
document.getElementById("resetView").onclick = () => {   // эталонный ракурс (наклон из core)
  Projection.reset(); zoom = 1.0; draw3d(); };
const c3d = document.getElementById("c3d");
let drag = null;
c3d.onmousedown = e => drag = [e.clientX, e.clientY];
const clamp = (v,a,b) => Math.max(a, Math.min(b, v));
window.onmousemove = e => { if(!drag) return;
  // ПОЛНОЕ орбитальное вращение: азимут по кругу (облёт), наклон ±80° (не перевернуть вверх дном).
  // В эталоне (кнопка «сброс вида») сцена согласована с полем; облёт лево-право меняет естественно.
  Projection.az += (e.clientX-drag[0])*0.008;
  Projection.el = clamp(Projection.el + (e.clientY-drag[1])*0.008, -1.4, 1.4);
  drag = [e.clientX, e.clientY]; draw3d(); };
window.onmouseup = () => drag = null;
c3d.onwheel = e => { e.preventDefault();
  zoom = Math.max(0.4, Math.min(3, zoom*(e.deltaY < 0 ? 1.1 : 0.9))); draw3d(); };
document.getElementById("tick").max = DATA.nTicks-1;
const hm = location.hash.match(/t=(\\d+)/);        // deep-link #t=N: открыть такт на паузе
if(hm){ tick = Math.min(DATA.nTicks-1, +hm[1]); playing = false;
  const pb = document.getElementById("play");
  pb.textContent = "▶ пуск"; pb.classList.remove("on"); }
drawAll(); schedule();
</script></body></html>
"""


def build_page(data: dict[str, Any], out_path: Path) -> Path:
    """Встроить данные в шаблон, записать самодостаточную страницу."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    out_path.write_text(_PAGE.replace("__DATA__", payload), encoding="utf-8")
    return out_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Живая web-панель ex4 (канон §1.6).")
    parser.add_argument("--tacts", type=int, default=None,
                        help="число тактов (дефолт — канон 30, решение Alex 1A)")
    args = parser.parse_args()

    p = Ex4Params() if args.tacts is None else Ex4Params(tacts=args.tacts)
    ex = Ex4Flight(params=p)
    ex.run_history(np.random.default_rng(ex.seed))
    data = history_to_json(ex)
    out = Path(__file__).resolve().parents[1] / "graphics" / "ex4_flight" / "web" / "index.html"
    path = build_page(data, out)
    print(f"ex4-web: {data['nTicks']} тактов · {path.stat().st_size // 1024} КБ · {ex._stats}")
    print("  открыть в браузере:", path)


if __name__ == "__main__":
    main()
